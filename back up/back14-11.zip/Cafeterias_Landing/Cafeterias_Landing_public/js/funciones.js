/**
 * Archivo con funciones genericas
 * 
 */


/**
 * Pasamos por parametro el numero de estrellas que queremos mostrar.
 * 
 * @param numRanking { type int} 
 * @returns {String}
 */
function armarRanking(numRanking){
  
  var star ='';
  
  for(var i = 0; i < numRanking; i++){
    
    star+='<i class="star fas fa-star"></i>';
    
  }
  
  return star;
  
}
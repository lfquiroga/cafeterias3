<?php

namespace CafeteriasBA\Controllers;
use CafeteriasBA\Core\View;
use CafeteriasBA\Models\Hash;
use CafeteriasBA\Models\Cafeteria as Cafeteria;
//use CafeteriasBA\Session\Session;

class CafeteriaController{

		// TODO: LLAMAR METODOS
		/**
			* metodo traer todos.
			*/
		public static function getAll()
		{
				$cafeterias = Cafeteria::getAll();
				$salida = 
				[
					'status' => 1,
					'data' => $cafeterias
				];
				View::render($salida);
		}

		/**
			* @param $data
			* @throws \Exception
			*/
		public static function Create($data)
		{
			$cafeteria = Cafeteria::crearCafeteria($data);
			$salida =
					[
						'status' => 1,
						'data' => $cafeteria
					];
			View::render($salida);
		}

		/**
			* @param $data
			* @throws \Exception
			*/
		public static function Update($data)
		{
				$cafeteria = Cafeteria::editarCafeteria($data);
				$salida =
					[
						'status' => 1,
						'data' => $cafeteria
					];
				View::render($salida);
		}

		/**
			* @param $id
			*/
		public static function getById($id)
		{
				$cafeteria = Cafeteria::verCafeteria($id);
				$salida =
					[
						'status' => 1,
						'data' => $cafeteria
					];
				View::render($salida);
		}

		/**
			* @param $id
			*/
		public static function Delete($id)
		{
			$cafeteria = Cafeteria::eliminarCafeteria($id);
			$salida = 
			[
				'status' => 1,
				'data' => $cafeteria
			];
                        
			View::render($salida);
		}

		public static function getRanking()
		{
			$cafeteriasRanking = Cafeteria::topRank();
			$salida = 
			[
				'status' => 1,
				'data' => $cafeteriasRanking
			];
                        
			View::render($cafeteriasRanking);
		}
		
}
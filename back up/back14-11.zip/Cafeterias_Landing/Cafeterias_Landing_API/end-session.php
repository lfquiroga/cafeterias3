<?php
require 'autoload.php';
use \CafeteriasBA\Session\Session;

Session::clearValue('Usuario');
if(isset($_SESSION['Admin']))
{
	Session::clearValue('Admin');
}
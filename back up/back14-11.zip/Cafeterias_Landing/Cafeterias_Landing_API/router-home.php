<?php
require 'autoload.php';
use \CafeteriasBA\Controllers\CafeteriaController;

CafeteriaController::getRanking();

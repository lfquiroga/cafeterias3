<?php
$pass = "1234";
$hashed = '$2y$10$Qotj8LoYRmyC5gWmqq62a.ayHuk6FutP6cemoh14.z43oL5v7HL8a';
function encrypt($pass)
{


		echo password_hash($pass, PASSWORD_DEFAULT);

}

encrypt($pass);
/*
function hashVerify ($password, $hashed)
{

        if(password_verify($password,$hashed)){
                echo true;
        }else{
                echo false;
        }
}

hashVerify($pass, $hashed);*/